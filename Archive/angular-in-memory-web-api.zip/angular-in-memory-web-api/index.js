export * from './http-status-codes';
export * from './in-memory-backend.service';
export * from './in-memory-web-api.module';
//# sourceMappingURL=index.js.map