import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<div>{{member?.name}}</div>`,
})
export class AppComponent {
//  member = {
//    name: '山田太郎',
//    age: 30
//  };
}